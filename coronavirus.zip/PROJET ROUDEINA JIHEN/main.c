#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<malloc.h>
#include"ELTPRIM.h"
#include"LSTPRIM.h"
#include"TABPRIM.h"
#include<time.h>

void SUPPRIMER (TAB T);
 void MODIFIER (TAB T);
void SAISIRE (TAB T);
void AFFICHER (TAB T);
void fichier(TAB T);
void permut(ELEMENT e1,ELEMENT e2);
void tri(LISTE L);
void GouverTrier(TAB T);
void ListeTrier(TAB T);



int main()
{

    //pour changer les valeurs des elements � chaque fois
srand(time(NULL));
//declaration
LISTE L1,L2,L3,L4,L5,L6,L7,L8,L9,L10,L11,L12,L13,L14,L15,L16,L17,L18,L19,L20,L21,L22,L23,L24;
TAB T;
char gouver[20];
int i,j,choix;
T=tabCreer();
FILE *fp;


L1=listeCreer();
L2=listeCreer();
L3=listeCreer();
L4=listeCreer();
L5=listeCreer();
L6=listeCreer();
L7=listeCreer();
L8=listeCreer();
L9=listeCreer();
L10=listeCreer();
L11=listeCreer();
L12=listeCreer();
L13=listeCreer();
L14=listeCreer();
L15=listeCreer();
L16=listeCreer();
L17=listeCreer();
L18=listeCreer();
L19=listeCreer();
L20=listeCreer();
L21=listeCreer();
L22=listeCreer();
L23=listeCreer();
L24=listeCreer();


tabinserer(T,L1,1);
tabinserer(T,L2,2);
tabinserer(T,L3,3);
tabinserer(T,L4,4);
tabinserer(T,L5,5);
tabinserer(T,L6,6);
tabinserer(T,L7,7);
tabinserer(T,L8,8);
tabinserer(T,L9,9);
tabinserer(T,L10,10);
tabinserer(T,L11,11);
tabinserer(T,L12,12);
tabinserer(T,L13,13);
tabinserer(T,L14,14);
tabinserer(T,L15,15);
tabinserer(T,L16,16);
tabinserer(T,L17,17);
tabinserer(T,L18,18);
tabinserer(T,L19,19);
tabinserer(T,L20,20);
tabinserer(T,L21,21);
tabinserer(T,L22,22);
tabinserer(T,L23,23);
tabinserer(T,L24,24);

strcpy(T->gouv[1]->nom, "ARIANA");
strcpy(T->gouv[2]->nom, "BEJA");
strcpy(T->gouv[3]->nom,"BENAROUS");
strcpy(T->gouv[4]->nom,"BENZART");
strcpy(T->gouv[5]->nom,"EL-KEF");
strcpy(T->gouv[6]->nom,"GABES");
strcpy(T->gouv[7]->nom,"GAFSA");
strcpy(T->gouv[8]->nom,"GASSRINE");
strcpy(T->gouv[9]->nom,"GBELLI");
strcpy(T->gouv[10]->nom,"JENDOUBA");
strcpy(T->gouv[11]->nom,"KEROUAN");
strcpy(T->gouv[12]->nom,"MAHDIYA");
strcpy(T->gouv[13]->nom,"MANOUBA");
strcpy(T->gouv[14]->nom,"MEDNINE");
strcpy(T->gouv[15]->nom,"MONASTIR");
strcpy(T->gouv[16]->nom,"NABEL");
strcpy(T->gouv[17]->nom,"SFAX");
strcpy(T->gouv[18]->nom,"SIDI-BOUZID");
strcpy(T->gouv[19]->nom,"SILIANA");
strcpy(T->gouv[20]->nom,"SOUSSE");
strcpy(T->gouv[21]->nom,"TATAOUIN");
strcpy(T->gouv[22]->nom,"TOUZER");
strcpy(T->gouv[23]->nom,"TUNIS");
strcpy(T->gouv[24]->nom,"ZAGHOUEN");




for(i=1;i<=24;i++)
{
    for(j=1;j<=20;j++)
{ ELEMENT e = ElementCreer();
  e->d.j=j;
  e->d.m=03;
  e->d.a=2021;
  e->positifs= rand()%1000;
  e->guerisons=rand()%100;
  e->deces=rand()%100;
  e->vaccines=rand()%100;
  strcpy(e->gouv,T->gouv[i]->nom);
  inserer(T->gouv[i],e,j);


}

}










printf("\n");
printf("            *****BIENVENUE*****\n\n\n");

do{

choix =menu();

    switch(choix)
      {
        case 1 :SAISIRE (T);break;
        case 2 :MODIFIER(T);break;
        case 3 :SUPPRIMER(T);break;
        case 4 :AFFICHER(T);break ;
        case 5 :ListeTrier(T) ;break;
        case 6 :GouverTrier(T);break;
        case 7 :fichier(T);

      }


}while(choix!=8);
printf("au revoir :) \n");


    return 0;
}




int menu (void)
{ int choix;
    printf("\n\n  ********************BIENVENUE********************\n\n");
    printf("         1-Saisir Des Nouveaux Statistiques\n\n");
    printf("             2-Modifier Des Coordonnees\n\n");
    printf("             3-Supprimer Des Coordonnees\n\n");
    printf("             4-afficher les statistiques\n\n");
    printf("   5-Trier Les Statistiques Selon Une Date Donnee\n\n");
    printf("     6-Trier Les Statistiques D'un Gouvernorat\n\n");
    printf("        7-Saisir Des Coordonees D'un Fichier\n\n");
    printf("                      8-Quitter\n\n");
scanf("%i",&choix);
return choix;
}




void AFFICHER (TAB T)
{ char gouver [30] ;
 int i,A ;
do{
 printf(" 1-afficher les statistiques de tous les gouvernorats \n ");
 printf("2-afficher les statistiques d'une gouvernorat \n");
 printf(" 3-quitter\n");

 scanf("%i",&A);
 if(A==1)
 {tabAfficher(T);}
 else{
 if(A==2)
    {printf("donner le gouvernorat demand%c \n",130);
            scanf("%s",gouver);
            i=1;
            for(i=1;i<=24;i++)
                {if(strcmp(T->gouv[i]->nom,gouver)==0)
                 {listeAfficher(T->gouv[i]);
                     }}
}}
}while(A!=3);
}
void SAISIRE (TAB T)
{ int i;
    printf("donner le date \n");
ELEMENT b =ElementCreer();
printf("donner le jour  \n");
scanf("%i",&(b->d.j));
printf("donner le mois  \n");
scanf("%i",&(b->d.m));
printf("donner l'annee  \n");
scanf("%i",&(b->d.a));

for(i=1;i<=24;i++)
{

ELEMENT e = ElementCreer();
  e->d.j=b->d.j;
  e->d.m=b->d.m;
  e->d.a=b->d.a;
  printf("donner le nombre des cas positifs :) \n ");
 scanf("%i",&(e->positifs));
 printf("donner le nombre des guerisons :) \n ");
 scanf("%i",&(e->guerisons));
printf("donner le nombre des deces :) \n ");
 scanf("%i",&(e->deces));
 printf("donner le nombre des vaccinees :) \n ");
 scanf("%i",&(e->vaccines));
  inserer(T->gouv[i],e,T->gouv[i]->lg+1);


}
}
 void MODIFIER (TAB T)
{

char gouver [30];
int trouve =0;
int i,j;
DATE l;
NOEUD a;

printf("donner la date a modifier \n");
printf(" le jour  \n \a");
scanf("%i",&(l.j));
printf(" le mois  \n\a");
scanf("%i",&(l.m));
printf(" l'annee  \n\a");
scanf("%i",&(l.a));
printf("donner le gouvernorat \n");
scanf("%s",gouver);
i=1;
while((i<24)&&(!trouve))
{if(strcmp(T->gouv[i]->nom,gouver)==0)
 {  trouve =1;
     a=T->gouv[i]->tete;

   for(j=1;j<T->gouv[j]->lg;j++)
    {
       if(DateComparer(a->info->d,l)==0)
         {
            printf("avant la modification les coordon%ces sont : \n",130);
         printf("le nombre des cas positifs : %i \n\n",a->info->positifs);
         printf("le nombre des gu%crisons :%i \n\n", 130, a->info->guerisons);
         printf("le nombre de d%cc%cs :%i \n\n", 130,138,a->info->deces  );
         printf("le nombre des vaccin%cs : %i \n\n",130,a->info->vaccines );
         printf("apr%cs la modification : \n\n\n", 130);
          printf("donner le nombre de cas positifs :) \n\n");
          scanf("%i",&((a)->info->positifs));
          printf("donner le nombre des gu%crisons :) \n\n", 130);
          scanf("%i",&((a)->info->guerisons));
          printf("donner le nombre de d%cc%cs :) \n\n", 130,138 );
          scanf("%i",&((a)->info->deces));
          printf("donner le nombre des vaccin%cs :) \n\n",130);
          scanf("%i",&((a)->info->vaccines));


           }
       a=a->suivant;

       }


 }
 else i++;
;

}
}
void SUPPRIMER (TAB T)
{
    int trouve =0 ,i,j;
    char gouver [30];
    printf("donner la date  \n");

DATE P;

printf(" le jour  \n \a");
scanf (" %i",&(P.j));
printf(" le mois  \n\a");
scanf (" %i",&(P.m));
printf(" l'annee  \n\a");
scanf (" %i",&(P.a));
printf("donner le gouvernorat \n");
scanf("%s",gouver);


ELEMENT r =ElementCreer();
i=1;
while((i<=24)&&(!trouve))
{if(strcmp(T->gouv[i]->nom,gouver)==0)
 {  trouve =1;

   for(j=1;j<T->gouv[i]->lg;j++)
    { r= recuperer(T->gouv[i],j);

       if(DateComparer(r->d,P)==0)
         {
             supprimer(T->gouv[i],j);

         }


    }
    listeAfficher(T->gouv[i]);
    } else i++;
    }
}

void ListeTrier(TAB T)
{
    LISTE L1=listeCreer();
    DATE d;

    printf("Date (jour/mois/annee): ");
    DateLire(&d);

    for(int i=0; i<24; i++)
    {
        int j=1;

        while(j<=listeTaille(T->gouv[i]) && DateComparer(d,recuperer(T->gouv[i],j)->d)!=0)
            j++;
        if(j<=listeTaille(T->gouv[i]))
            inserer(L1,recuperer(T->gouv[i],j),listeTaille(L1)+1);
    }
    system("cls");
    tri(L1);
}
void GouverTrier(TAB T)
{
    char nom[20];

    printf("DONNER UN GOUVERNORAT : ");
    scanf("%s",nom);
    int i=0,test=0;
    while(i<24 && !test)
    {
        int j=0;
        while(j<strlen(T->gouv[i]->nom) && (T->gouv[i]->nom)[j]==toupper(nom[j]))
            j++;
        if(j==strlen(T->gouv[i]->nom))
            test=1;
        else
            i++;
    }
    system("cls");
    tri(T->gouv[i]);
}

void tri(LISTE L)
{
    ELEMENT e1,e2;
    int j=listeTaille(L);
    int choix;

    int positifs,guerisons,deces,vaccines;
    printf("ORGANISER CES CRITERES : \n");

    printf("Cas Positifs : ");
    scanf("%i",&positifs);

    printf("Guerisons : ");
    scanf("%i",&guerisons);

    printf("Deces : ");
    scanf("%i",&deces);

    printf("Vaccines : ");
    scanf("%i",&vaccines);

    printf("\nORDRE : \n1-Croissant\n2-Decroissant\n");
    scanf("%i",&choix);
    system("cls");

    while(j>0)
    {
        for(int i=1; i<j; i++)
        {
            if(choix==1)
            {
                e2=recuperer(L,i);
                e1=recuperer(L,i+1);
            }
            else if(choix==2)
            {
                e1=recuperer(L,i);
                e2=recuperer(L,i+1);
            }

            if(positifs==1)
            {
                if(e1->positifs<e2->positifs)
                    permut(e1,e2);
                else if(e1->positifs==e2->positifs)
                {
                    if(guerisons==2)
                    {
                        if(e1->guerisons<e2->guerisons)
                            permut(e1,e2);
                        else if(e1->guerisons==e2->guerisons)
                        {
                            if(deces==3)
                            {
                                if(e1->deces<e2->deces)
                                    permut(e1,e2);
                                else if(e1->deces==e2->deces)
                                {
                                    if(e1->vaccines<e2->vaccines)
                                        permut(e1,e2);
                                }
                            }

                            if(vaccines==3)
                            {
                                if(e1->vaccines<e2->vaccines)
                                    permut(e1,e2);
                                else if(e1->vaccines==e2->vaccines)
                                {
                                    if(e1->deces<e2->deces)
                                        permut(e1,e2);
                                }
                            }
                        }
                    }
                    if(deces==2)
                    {
                        if(e1->deces<e2->deces)
                            permut(e1,e2);
                        else if(e1->deces==e2->deces)
                        {
                            if(guerisons==3)
                            {
                                if(e1->guerisons<e2->guerisons)
                                    permut(e1,e2);
                                else if(e1->guerisons==e2->guerisons)
                                {
                                    if(e1->vaccines<e2->vaccines)
                                        permut(e1,e2);
                                }
                            }
                            if(vaccines==3)
                            {
                                if(e1->vaccines<e2->vaccines)
                                    permut(e1,e2);
                                else if(e1->vaccines==e2->vaccines)
                                {
                                    if(e1->guerisons<e2->guerisons)
                                        permut(e1,e2);
                                }
                            }
                        }
                    }
                    if(vaccines==2)
                    {
                        if(e1->vaccines<e2->vaccines)
                            permut(e1,e2);
                        else if(e1->vaccines==e2->vaccines)
                        {
                            if(deces==3)
                            {
                                if(e1->deces<e2->deces)
                                    permut(e1,e2);
                                else if(e1->deces==e2->deces)
                                {
                                    if(e1->guerisons<e2->guerisons)
                                        permut(e1,e2);
                                }
                            }
                            if(guerisons==3)
                            {
                                if(e1->guerisons<e2->guerisons)
                                    permut(e1,e2);
                                else if(e1->guerisons==e2->guerisons)
                                {
                                    if(e1->deces<e2->deces)
                                        permut(e1,e2);
                                }
                            }
                        }
                    }
                }
            }
            if(guerisons==1)
            {
                if(e1->guerisons<e2->guerisons)
                    permut(e1,e2);
                else if(e1->guerisons==e2->guerisons)
                {
                    if(positifs==2)
                    {
                        if(e1->positifs<e2->positifs)
                            permut(e1,e2);
                        else if(e1->positifs==e2->positifs)
                        {
                            if(deces==3)
                            {
                                if(e1->deces<e2->deces)
                                    permut(e1,e2);
                                else if(e1->deces==e2->deces)
                                {
                                    if(e1->vaccines<e2->vaccines)
                                        permut(e1,e2);
                                }
                            }
                            if(vaccines==3)
                            {
                                if(e1->vaccines<e2->vaccines)
                                    permut(e1,e2);
                                else if(e1->vaccines==e2->vaccines)
                                {
                                    if(e1->deces<e2->deces)
                                        permut(e1,e2);
                                }
                            }
                        }
                    }
                    if(deces==2)
                    {
                        if(e1->deces<e2->deces)
                            permut(e1,e2);
                        else if(e1->deces==e2->deces)
                        {
                            if(positifs==3)
                            {
                                if(e1->positifs<e2->positifs)
                                    permut(e1,e2);
                                else if(e1->positifs==e2->positifs)
                                {
                                    if(e1->vaccines<e2->vaccines)
                                        permut(e1,e2);
                                }
                            }
                            if(vaccines==3)
                            {
                                if(e1->vaccines<e2->vaccines)
                                    permut(e1,e2);
                                else if(e1->vaccines==e2->vaccines)
                                {
                                    if(e1->positifs<e2->positifs)
                                        permut(e1,e2);
                                }
                            }
                        }
                    }
                    if(vaccines==2)
                    {
                        if(e1->vaccines<e2->vaccines)
                            permut(e1,e2);
                        else if(e1->vaccines==e2->vaccines)
                        {
                            if(deces==3)
                            {
                                if(e1->deces<e2->deces)
                                    permut(e1,e2);
                                else if(e1->deces==e2->deces)
                                {
                                    if(e1->positifs<e2->positifs)
                                        permut(e1,e2);
                                }
                            }
                            if(positifs==3)
                            {
                                if(e1->positifs<e2->positifs)
                                    permut(e1,e2);
                                else if(e1->positifs==e2->positifs)
                                {
                                    if(e1->deces<e2->deces)
                                        permut(e1,e2);
                                }
                            }
                        }
                    }
                }
            }
            if(deces==1)
            {
                if(e1->deces<e2->deces)
                    permut(e1,e2);
                else if(e1->deces==e2->deces)
                {
                    if(positifs==2)
                    {
                        if(e1->positifs<e2->positifs)
                            permut(e1,e2);
                        else if(e1->positifs==e2->positifs)
                        {
                            if(guerisons==3)
                            {
                                if(e1->guerisons<e2->guerisons)
                                    permut(e1,e2);
                                else if(e1->guerisons==e2->guerisons)
                                {
                                    if(e1->vaccines<e2->vaccines)
                                        permut(e1,e2);
                                }
                            }
                            if(vaccines==3)
                            {
                                if(e1->vaccines<e2->vaccines)
                                    permut(e1,e2);
                                else if(e1->vaccines==e2->vaccines)
                                {
                                    if(e1->guerisons<e2->guerisons)
                                        permut(e1,e2);
                                }
                            }
                        }
                    }
                    if(guerisons==2)
                    {
                        if(e1->guerisons<e2->guerisons)
                            permut(e1,e2);
                        else if(e1->guerisons==e2->guerisons)
                        {
                            if(positifs==3)
                            {
                                if(e1->positifs<e2->positifs)
                                    permut(e1,e2);
                                else if(e1->positifs==e2->positifs)
                                {
                                    if(e1->vaccines<e2->vaccines)
                                        permut(e1,e2);
                                }
                            }
                            if(vaccines==3)
                            {
                                if(e1->vaccines<e2->vaccines)
                                    permut(e1,e2);
                                else if(e1->vaccines==e2->vaccines)
                                {
                                    if(e1->positifs<e2->positifs)
                                        permut(e1,e2);
                                }
                            }
                        }
                    }
                    if(vaccines==2)
                    {
                        if(e1->vaccines<e2->vaccines)
                            permut(e1,e2);
                        else if(e1->vaccines==e2->vaccines)
                        {
                            if(positifs==3)
                            {
                                if(e1->positifs<e2->positifs)
                                    permut(e1,e2);
                                else if(e1->positifs==e2->positifs)
                                {
                                    if(e1->guerisons<e2->guerisons)
                                        permut(e1,e2);
                                }
                            }
                            if(guerisons==3)
                            {
                                if(e1->guerisons<e2->guerisons)
                                    permut(e1,e2);
                                else if(e1->guerisons==e2->guerisons)
                                {
                                    if(e1->positifs<e2->positifs)
                                        permut(e1,e2);
                                }
                            }
                        }
                    }
                }
            }
            if(vaccines==1)
            {
                if(e1->vaccines<e2->vaccines)
                    permut(e1,e2);
                else if(e1->vaccines==e2->vaccines)
                {
                    if(positifs==2)
                    {
                        if(e1->positifs<e2->positifs)
                            permut(e1,e2);
                        else if(e1->positifs==e2->positifs)
                        {
                            if(guerisons==3)
                            {
                                if(e1->guerisons<e2->guerisons)
                                    permut(e1,e2);
                                else if(e1->guerisons==e2->guerisons)
                                {
                                    if(e1->deces<e2->deces)
                                        permut(e1,e2);
                                }
                            }
                            if(deces==3)
                            {
                                if(e1->deces<e2->deces)
                                    permut(e1,e2);
                                else if(e1->deces==e2->deces)
                                {
                                    if(e1->guerisons<e2->guerisons)
                                        permut(e1,e2);
                                }
                            }
                        }
                    }
                    if(guerisons==2)
                    {
                        if(e1->guerisons<e2->guerisons)
                            permut(e1,e2);
                        else if(e1->guerisons==e2->guerisons)
                        {
                            if(positifs==3)
                            {
                                if(e1->positifs<e2->positifs)
                                    permut(e1,e2);
                                else if(e1->positifs==e2->positifs)
                                {
                                    if(e1->deces<e2->deces)
                                        permut(e1,e2);
                                }
                            }
                            if(deces==3)
                            {
                                if(e1->deces<e2->deces)
                                    permut(e1,e2);
                                else if(e1->deces==e2->deces)
                                {
                                    if(e1->positifs<e2->positifs)
                                        permut(e1,e2);
                                }
                            }
                        }
                    }
                    if(deces==2)
                    {
                        if(e1->deces<e2->deces)
                            permut(e1,e2);
                        else if(e1->deces==e2->deces)
                        {
                            if(positifs==3)
                            {
                                if(e1->positifs<e2->positifs)
                                    permut(e1,e2);
                                else if(e1->positifs==e2->positifs)
                                {
                                    if(e1->guerisons<e2->guerisons)
                                        permut(e1,e2);
                                }
                            }
                            if(guerisons==3)
                            {
                                if(e1->guerisons<e2->guerisons)
                                    permut(e1,e2);
                                else if(e1->guerisons==e2->guerisons)
                                {
                                    if(e1->positifs<e2->positifs)
                                        permut(e1,e2);
                                }
                            }
                        }
                    }
                }
            }
        }
        j--;
    }

    listeAfficher(L);
}
void permut(ELEMENT e1,ELEMENT e2)
{
    ELEMENT aux=ElementCreer();

    ElementCopier(&aux,e1);
    ElementCopier(&e1,e2);
    ElementCopier(&e2,aux);
}

void fichier(TAB T)
{
    FILE *f;
    char filename[100],str[40],m[8][12];
    ELEMENT e;
    printf("Donner Le Chemin De Fichier : ");
    scanf("%s",filename);

    f=fopen(filename,"r");
    while(fgets(str,40,f)!=NULL)
    {
        e=ElementCreer();
        int j=0,k=0;
        for(int i=0; i<40; i++)
        {
            if(str[i]!='#')
                m[j][k]=str[i];
            else
            {
                m[j][k]='\0';
                j++;
                k=-1;
            }
            k++;
        }

        strcpy(e->gouv,m[0]);
        e->d.j=atoi(m[1]);
        e->d.m=atoi(m[2]);
        e->d.a=atoi(m[3]);
        e->positifs=atoi(m[4]);
        e->guerisons=atoi(m[5]);
        e->deces=atoi(m[6]);
        e->vaccines=atoi(m[7]);
        ElementAfficher(e);

        int i=0;
        while(i<24 && strcmp(e->gouv,T->gouv[i]->nom))
            i++;
        if(i<24)
        {
            int j=1;
            while(j<=listeTaille(T->gouv[i]) && DateComparer(e->d,recuperer(T->gouv[i],j)->d)>0)
                j++;

            if(j<=listeTaille(T->gouv[i]))
                supprimer(T->gouv[i],j);
            inserer(T->gouv[i],e,j);
        }
        listeAfficher(T->gouv[i]);
    }
}


