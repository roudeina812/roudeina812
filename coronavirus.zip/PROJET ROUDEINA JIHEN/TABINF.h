#ifndef TABINF_H_INCLUDED
#define TABINF_H_INCLUDED

#include"LSTPRIM.h"
typedef struct {
LISTE gouv[26];
int LG;

}laStruct,* TAB;


#endif // TABINF_H_INCLUDED
