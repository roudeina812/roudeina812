#ifndef TABSDD_H_INCLUDED
#define TABSDD_H_INCLUDED

#include"TABINF.h"

#endif // TABSDD_H_INCLUDED
